package cineapp;
import Interfaz.Interfaz;
public class CineApp {
    public static void main(String[] args) {
        LlenarSalas obj1 = new LlenarSalas();
        obj1.llenarSalas();
        Interfaz in = new Interfaz(obj1); 
        in.setVisible(true);
    }
}


