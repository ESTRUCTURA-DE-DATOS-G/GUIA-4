package cineapp;

import javax.swing.JOptionPane;

public class Prueba {
    
    public void menuOpciones(LlenarSalas salas, String dato) {
        if (salas.getAsistencia() != null) {
            int maxAsistencia = 0;
            int minAsistencia = Integer.MAX_VALUE;
            int salaMasVista = 0;
            int peliculaMasVista = 0;
            int salaMenosVista = 0;
            int peliculaMenosVista = 0;

            for (int sala = 0; sala < salas.getAsistencia().length; sala++) {
                for (int pelicula = 0; pelicula < 3; pelicula++) {
                    int asistencia = salas.getAsistencia()[sala][pelicula];
                    if (asistencia > maxAsistencia) {
                        maxAsistencia = asistencia;
                        salaMasVista = sala + 1;
                        peliculaMasVista = pelicula + 1;
                    }
                    if (asistencia < minAsistencia) {
                        minAsistencia = asistencia;
                        salaMenosVista = sala + 1;
                        peliculaMenosVista = pelicula + 1;
                    }
                }
            }

            if ("MEJOR COMBO-SALA".equals(dato)) {
                JOptionPane.showMessageDialog(null, "La mejor combinación sala-película es: Sala " + salaMasVista + ", Película " + peliculaMasVista + ", con " + maxAsistencia + " asistentes.", "AVISO", JOptionPane.INFORMATION_MESSAGE);
            } else if ("PELICULA MAS VISTA".equals(dato)) {
                JOptionPane.showMessageDialog(null, "La película más vista es: Sala " + salaMasVista + ", Película " + peliculaMasVista + ", con " + maxAsistencia + " asistentes.", "AVISO", JOptionPane.INFORMATION_MESSAGE);
            } else if ("PELICULA MENOS VISTA".equals(dato)) {
                JOptionPane.showMessageDialog(null, "La película menos vista es: Sala " + salaMenosVista + ", Película " + peliculaMenosVista + ", con " + minAsistencia + " asistentes.", "AVISO", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Opción no válida.", "AVISO", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se ha cargado la asistencia todavía.", "AVISO", JOptionPane.WARNING_MESSAGE);
        }
    }
}
