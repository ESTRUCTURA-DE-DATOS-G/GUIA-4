package cineapp;

import javax.swing.JOptionPane;

public class LlenarSalas {

    int numeroSalas = 2;
    int numeroPeliculas = 3;
    int asistencia[][] = new int[numeroSalas][numeroPeliculas];

    public void llenarSalas() {

        for (int sala = 0; sala < numeroSalas; sala++) {
            for (int pelicula = 0; pelicula < numeroPeliculas; pelicula++) {
                String input = JOptionPane.showInputDialog("Ingrese la asistencia para la sala " + (sala + 1)
                        + " y la película " + (pelicula + 1));
                asistencia[sala][pelicula] = Integer.parseInt(input);
            }
        }

        JOptionPane.showMessageDialog(null, "SALAS LLENAS", "AVISO", JOptionPane.INFORMATION_MESSAGE);

        System.out.println("Imprimiendo la matriz de asistencia:");
        for (int sala = 0; sala < asistencia.length; sala++) {
            System.out.print("Sala " + (sala + 1) + ": ");
            for (int pelicula = 0; pelicula < asistencia[sala].length; pelicula++) {
                System.out.print(asistencia[sala][pelicula] + " ");
            }
            System.out.println();
        }
        
        mostrarMatriz();

    }

    public int[][] getAsistencia() {
        return asistencia;
    }
    
     public void mostrarMatriz(){
        for (int sala = 0; sala < 2; sala++) {
            for (int pelicula = 0; pelicula < 3; pelicula++) {
                System.out.println(asistencia[sala][pelicula]);
            }
        }
    
    
    }
}
