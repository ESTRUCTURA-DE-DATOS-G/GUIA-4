package Logica;

import GUI.Inicio;

public class Ordenamiento {

    public static void main(String[] args) {
        Inicio in = new Inicio();
        in.setVisible(true);
    }
}
