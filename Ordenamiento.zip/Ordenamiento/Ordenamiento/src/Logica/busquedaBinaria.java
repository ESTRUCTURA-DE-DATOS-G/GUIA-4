package Logica;

public class busquedaBinaria {
    
    public int metodoBinario(int[] vector, int elemento){
        int izquierda = 0;
        int derecha = vector.length-1;
        
        while(izquierda <= derecha){
            int medio = izquierda + (derecha - izquierda) / 2;
            
            //Si el elemento esta en el medio, lo encontramos
            if(vector[medio] == elemento){
                return medio;
            }
            
            //Si el elemento es mayor que el del medio se decarga la mitad de la izquierda
            if(vector[medio] < elemento){
                izquierda = medio+1;
            }
            
            //Si el elemento es mejor que el del medio se descarga el de la derecha
            else{
                derecha = medio-1;
            }
        }
        return -1;
    }
}
