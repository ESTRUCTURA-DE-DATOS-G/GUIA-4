package Logica;

import java.util.ArrayList;

public class Ordenamientos extends LlenarVector {

    private int aux = 0;
    double tiempoBurbuja, tiempoSeleccion, tiempoShell, tiempoInsercion, tiempoQuick, tiempoHeap;
    double tiempoBurbuja1, tiempoSeleccion1, tiempoShell1, tiempoInsercion1, tiempoQuick1, tiempoHeap1;

    public double getTiempoBurbuja1() {
        return tiempoBurbuja1;
    }

    public double getTiempoSeleccion1() {
        return tiempoSeleccion1;
    }

    public double getTiempoShell1() {
        return tiempoShell1;
    }

    public double getTiempoInsercion1() {
        return tiempoInsercion1;
    }

    public double getTiempoQuick1() {
        return tiempoQuick1;
    }

    public double getTiempoHeap1() {
        return tiempoHeap1;
    }

    public double getTiempoBurbuja() {
        return tiempoBurbuja;
    }

    public double getTiempoSeleccion() {
        return tiempoSeleccion;
    }

    public double getTiempoShell() {
        return tiempoShell;
    }

    public double getTiempoInsercion() {
        return tiempoInsercion;
    }

    public double getTiempoQuick() {
        return tiempoQuick;
    }

    public double getTiempoHeap() {
        return tiempoHeap;
    }

    

    public void ordenamientoBurbuja(int[] vector) {
        int fila = vector.length;

        long start = System.currentTimeMillis();
        long iniciar = System.nanoTime();
        for (int i = 0; i < fila - 1; i++) {
            for (int j = i + 1; j < fila; j++) {
                if (vector[i] > vector[j]) { //compara posiciones
                    aux = vector[i]; //guarda posicion en auxiliar para no perderla 
                    vector[i] = vector[j]; //cambia de posiciones
                    vector[j] = aux; //intercambia y pone el auxiliar en la pisicion cambiada
                }

            }

        }
        
        long end = System.currentTimeMillis();
        long terminar = System.nanoTime();
        tiempoBurbuja1 = (terminar - iniciar);
        tiempoBurbuja = (end - start);
        
    }

    

    public void ordenamientoSeleccion(int[] vector) {
        int menor, posicion, temporal;
        
        long start = System.currentTimeMillis();
        long iniciar = System.nanoTime();
        for (int i = 0; i < vector.length - 1; i++) { //Se toma como menor el primero
            menor = vector[i]; //Los elementos que quedan por ordenar
            posicion = i; //Guardar la posicion
            for (int j = i + 1; j < vector.length; j++) { //Se busca el resto en el vector
                if (vector[j] < menor) { //Si es menor la posicion que el menor escogido
                    menor = vector[j]; //Se reemplaza pues es menor que el de la posicion
                    posicion = j; //Posicion se actualiza
                }
            }
            if (posicion != i) { //Si hay alguno menor se intercambian
                temporal = vector[i]; //Guarda la posicion en un temporal
                vector[i] = vector[posicion]; //Guarda la posicion intercambiando
                vector[posicion] = temporal; //Cambia el vector posicion por el temporal
            }
        }
        
        long terminar = System.nanoTime();
        long end = System.currentTimeMillis();
        tiempoSeleccion1 = (terminar - iniciar);
        tiempoSeleccion=(end-start);
        
    }

    public void ordenamientoShellSort(int[] vector) {
        int salto, auxiliar;
        boolean cambios;
        
        long start = System.currentTimeMillis();
        long iniciar = System.nanoTime();
        for (salto = vector.length / 2; salto != 0; salto /= 2) {
            cambios = true;
            while (cambios) { //Mientras hayan intercambios realizar
                cambios = false;
                for (int i = salto; i < vector.length; i++) { //Hay una pasada
                    if (vector[i - salto] > vector[i]) { //Si estan desordenados
                        auxiliar = vector[i]; //Se reordena
                        vector[i] = vector[i - salto];
                        vector[i - salto] = auxiliar;
                        cambios = true; //Se realiza el cambio
                    }
                }
            }
        }
        long end = System.currentTimeMillis();
        long terminar = System.nanoTime();
        tiempoShell1=(terminar-iniciar);
        tiempoShell=(end-start);
        
        
    }

    public void ordenamientoInsercion(int[] vector) {
        //Crea dos vectores o matrices para poder insertar del desordenado a la ordenada
        long start = System.currentTimeMillis();
        long iniciar = System.nanoTime();
        for (int i = 1; i < vector.length; i++) {
            int key = vector[i]; //Se le asigna un axiliar o llave para guardar la posicion del vector
            int j = i - 1; //se iguala a i - 1 para iniciar en el 0

            while ((j >= 0) && (key < vector[j])) { //Se crea un while donde se cumplen dos condiciones donde la pisicion debe ser mayor o igual a 0 y la Key menor a la posicion escogida del vector
                vector[j + 1] = vector[j]; //Se va a aumentar una posicion y se igualara a la posicion del vector
                j = j - 1; //Se devuelve una posicion para volver a contrastar
            }
            vector[j + 1] = key;
        }
        long end = System.currentTimeMillis();
        long terminar = System.nanoTime();
        tiempoInsercion = (end - start);
        tiempoInsercion1 = (terminar - iniciar);
        
    }

    public void ordenamientoTipoQuicksort(int[] vector, int izq, int der) {
        int elemento = vector[izq]; //pivote
        int i = izq;
        int j = der;
        
        long start = System.currentTimeMillis();
        long iniciar = System.nanoTime();
        while (i < j) { //Se comparan
            while (vector[i] <= elemento && i < j) { //se empieza a mirar las casillas
                i++;
            }
            while (vector[j] > elemento) { //compara con el pivote
                j--;
            }
            if (i < j) { //compara con posiciones
                aux = vector[i];
                vector[i] = vector[j];
                vector[j] = aux;
            }
        }

        vector[izq] = vector[j]; //Se intercambia por lados
        vector[j] = elemento; //Se iguala al pivote
        if (izq < j - 1) {
            ordenamientoTipoQuicksort(vector, izq, j - 1); //Se pasa a un lado siendo menor
        }
        if (j + 1 < der) {
            ordenamientoTipoQuicksort(vector, j + 1, der); //Se pasa al otro contrastando si el derecho es mayor
        }
        
         long end = System.currentTimeMillis();
         long terminar = System.nanoTime();
         tiempoQuick=(end-start);
         tiempoQuick1=(terminar-iniciar);
    }

    public void ordenamientoHeapSort(int[] vector) {
        int n = vector.length;
        
        // Construir el heap (reorganizar el arreglo)
        long start = System.currentTimeMillis();
        long iniciar = System.nanoTime();
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(vector, n, i);
        }

        // Extraer elementos uno por uno del heap
        for (int i = n - 1; i > 0; i--) {
            // Mover la raíz actual al final del arreglo
            int temp = vector[0];
            vector[0] = vector[i];
            vector[i] = temp;

            // Llamar al heapify en el subárbol reducido
            heapify(vector, i, 0);
        }
        long end = System.currentTimeMillis();
        long terminar = System.nanoTime();
        tiempoHeap=(end-start);
        tiempoHeap1=(terminar-iniciar);
    }

// Para hacer un subárbol en el índice i que es un nodo raíz de un heap. n es el tamaño del heap
    void heapify(int[] vector, int n, int i) {
        int largest = i; // Inicializar el índice más grande como raíz
        int left = 2 * i + 1; // izquierda = 2*i + 1
        int right = 2 * i + 2; // derecha = 2*i + 2

        // Si el hijo izquierdo es más grande que la raíz
        if (left < n && vector[left] > vector[largest]) {
            largest = left;
        }

        // Si el hijo derecho es más grande que el más grande hasta ahora
        if (right < n && vector[right] > vector[largest]) {
            largest = right;
        }

        // Si el mayor no es la raíz
        if (largest != i) {
            int swap = vector[i];
            vector[i] = vector[largest];
            vector[largest] = swap;

            // Recursivamente hacer heapify en el subárbol afectado
            heapify(vector, n, largest);

        }
    }
}
