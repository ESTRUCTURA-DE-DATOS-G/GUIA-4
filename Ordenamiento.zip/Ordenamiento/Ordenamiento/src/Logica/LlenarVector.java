package Logica;

public class LlenarVector {

    private int vector[];

    public int[] llenarVector(int tamano) {
        vector = new int[tamano];

        for (int i = 0; i < vector.length; i++) {
            vector[i] = (int) (Math.random() * 200);
        }
        return vector;
    }

    public int[] getVector() {
        return vector;
    }
}
