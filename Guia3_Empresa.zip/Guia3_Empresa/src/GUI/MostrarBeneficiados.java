package GUI;

import guia3_empresa.Bonificacion;
import guia3_empresa.EmpleadoDAO;
import guia3_empresa.EmpleadoVO;
import guia3_empresa.MayorMenorBonificacion;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class MostrarBeneficiados extends javax.swing.JFrame {

    Bonificacion bonificacion;

    public MostrarBeneficiados(Bonificacion Bonificacion, EmpleadoDAO empleadoDAO) {
        initComponents();
        this.setLocationRelativeTo(null);
        bonificacion = Bonificacion;
        bonificacion.SueldosMasBajos(empleadoDAO);
        mostrarTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableEmpleados = new javax.swing.JTable();
        btnVolver1 = new javax.swing.JButton();
        EmpleadoMayor = new javax.swing.JLabel();
        EmpleadoMayor1 = new javax.swing.JLabel();
        EmpleadoMayor3 = new javax.swing.JLabel();
        EmpleadoMayor2 = new javax.swing.JLabel();
        EmpleadoMayor4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        jTableEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableEmpleados);

        btnVolver1.setBackground(new java.awt.Color(17, 0, 66));
        btnVolver1.setFont(new java.awt.Font("Lucida Console", 0, 20)); // NOI18N
        btnVolver1.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver1.setText("Volver");
        btnVolver1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolver1ActionPerformed(evt);
            }
        });

        EmpleadoMayor.setBackground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor.setFont(new java.awt.Font("Lucida Console", 0, 14)); // NOI18N
        EmpleadoMayor.setForeground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor.setText("Empleado(os) con:");

        EmpleadoMayor1.setBackground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor1.setFont(new java.awt.Font("Lucida Console", 0, 14)); // NOI18N
        EmpleadoMayor1.setForeground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor1.setText("Mayor bonificacion");

        EmpleadoMayor3.setBackground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor3.setFont(new java.awt.Font("Lucida Console", 0, 14)); // NOI18N
        EmpleadoMayor3.setForeground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor3.setText("Menor bonificacion");

        EmpleadoMayor2.setBackground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor2.setFont(new java.awt.Font("Lucida Console", 2, 14)); // NOI18N
        EmpleadoMayor2.setForeground(java.awt.SystemColor.textHighlight);
        EmpleadoMayor2.setText("Color azul");

        EmpleadoMayor4.setBackground(new java.awt.Color(255, 255, 255));
        EmpleadoMayor4.setFont(new java.awt.Font("Lucida Console", 2, 14)); // NOI18N
        EmpleadoMayor4.setForeground(new java.awt.Color(153, 153, 153));
        EmpleadoMayor4.setText("Color gris");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(EmpleadoMayor1)
                .addGap(60, 60, 60)
                .addComponent(EmpleadoMayor3)
                .addGap(76, 76, 76))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(162, 162, 162)
                        .addComponent(EmpleadoMayor))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(184, 184, 184)
                        .addComponent(btnVolver1)))
                .addContainerGap(15, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addComponent(EmpleadoMayor2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(EmpleadoMayor4)
                .addGap(106, 106, 106))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(EmpleadoMayor, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmpleadoMayor1)
                    .addComponent(EmpleadoMayor3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmpleadoMayor2)
                    .addComponent(EmpleadoMayor4))
                .addGap(19, 19, 19)
                .addComponent(btnVolver1)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolver1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolver1ActionPerformed
        super.dispose();
    }//GEN-LAST:event_btnVolver1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel EmpleadoMayor;
    private javax.swing.JLabel EmpleadoMayor1;
    private javax.swing.JLabel EmpleadoMayor2;
    private javax.swing.JLabel EmpleadoMayor3;
    private javax.swing.JLabel EmpleadoMayor4;
    private javax.swing.JButton btnVolver1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableEmpleados;
    // End of variables declaration//GEN-END:variables

    private void mostrarTabla() {
        MayorMenorBonificacion m = new MayorMenorBonificacion();
        m.setBonificacion(bonificacion);
        DefaultTableModel mt = new DefaultTableModel(new String[]{"Rut", "Nombre", "Apellido", "Sueldo", "Sueldo + 5%"}, (bonificacion.getEmpleadosBeneficiados().size()));

        jTableEmpleados.setModel(mt);

        TableModel modeloDatos = jTableEmpleados.getModel();

        int fila = 0;
        for (Map.Entry<Integer, EmpleadoVO> entry : bonificacion.getEmpleadosBeneficiados().entrySet()) {
            EmpleadoVO empleadoVO = entry.getValue();
            if (empleadoVO != null) {
                modeloDatos.setValueAt(empleadoVO.getRutEmpleado(), fila, 0);
                modeloDatos.setValueAt(empleadoVO.getNombreEmpleado(), fila, 1);
                modeloDatos.setValueAt(empleadoVO.getApellidoEmpleado(), fila, 2);
                modeloDatos.setValueAt(empleadoVO.getSueldoEmpleado(), fila, 3);
                modeloDatos.setValueAt(empleadoVO.getSueldoMasAumento(), fila, 4);
                fila++;
            }
        }

       

        for (int i = 0; i < jTableEmpleados.getColumnCount(); i++) {
            jTableEmpleados.getColumnModel().getColumn(i).setCellRenderer(m);
        }

    }
}
