/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guia3_empresa;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class MayorMenorBonificacion extends DefaultTableCellRenderer {

    Bonificacion bonificacion;

    public void setBonificacion(Bonificacion Bonificacion) {
        bonificacion = Bonificacion;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        bonificacion.MayorBonificacion();
        bonificacion.MenorBonificacion();
        Object cellValue = table.getValueAt(row, 3);
        if (cellValue != null && cellValue.equals(bonificacion.getMayorBonificacion())) {
            this.setBackground(Color.CYAN);
            
        } else {
            if (cellValue != null && cellValue.equals(bonificacion.getMenorBonificacion())) {
                this.setBackground(Color.LIGHT_GRAY);
                this.setForeground(Color.BLACK);
                
            }else{
                this.setBackground(Color.white);
                this.setForeground(Color.BLACK);
            }
        }

        return this;
    }

}
