package guia3_empresa;

import GUI.ActualizarEmpleado;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Random;
import javax.swing.JOptionPane;

public class EmpleadoDAO {

    private HashMap<Integer, EmpleadoVO> infoEmpleados;
    private int arrayRut[];
    Bonificacion bonificacion;

    private String[] nombres = {"Juan", "Alejandro", "Pedro", "Liliana", "Valentina",
        "Santiago", "Mateo", "Sofía", "Sebastián", "Isabella",
        "Leonardo", "Camila", "Daniel", "Victoria", "Alejandro",
        "Lucía", "Nicolás", "Mariana", "Diego", "Gabriela",};

    private String[] apellidos = {"Rodríguez", "García", "Martínez", "López", "Hernández",
        "Pérez", "González", "Sánchez", "Ramírez", "Torres",
        "Flores", "Díaz", "Ruiz", "Gómez", "Vásquez",
        "Castillo", "Morales", "Reyes", "Fernández", "Rivera"};

    public EmpleadoDAO(HashMap<Integer, EmpleadoVO> infoEmpleados, int[] arrayRut) {
        this.infoEmpleados = infoEmpleados;
        this.arrayRut = arrayRut;

    }

    public EmpleadoDAO() {
        this.infoEmpleados = new HashMap<>();
        this.arrayRut = new int[0];

    }

    public HashMap<Integer, EmpleadoVO> getInfoEmpleados() {
        return infoEmpleados;
    }

    public void setInfoEmpleados(HashMap<Integer, EmpleadoVO> infoEmpleados) {
        this.infoEmpleados = infoEmpleados;
    }

    public int[] getArrayRut() {
        return arrayRut;
    }

    public void setArrayRut(int[] arrayRut) {
        this.arrayRut = arrayRut;
    }

    

    public void registrarEmpleado(int cantidadEmpleados, Bonificacion Bonificacion) {
        bonificacion = Bonificacion;
        Random random = new Random();
        int[] sueldos = new int[cantidadEmpleados];
        arrayRut = new int[cantidadEmpleados];

        for (int i = 0; i < cantidadEmpleados; i++) {
            EmpleadoVO empleadoVO = new EmpleadoVO();
            empleadoVO.setRutEmpleado(i);
            empleadoVO.setSueldoEmpleado(random.nextInt(7)*1200000);
            empleadoVO.setSueldoMasAumento((int) (empleadoVO.getSueldoEmpleado() + (empleadoVO.getSueldoEmpleado() * 0.05)));

            if (empleadoVO.getSueldoEmpleado() == 0) {
                empleadoVO.setSueldoEmpleado(2600000);
                empleadoVO.setSueldoMasAumento((int) (2600000+(2600000*0.005)));
            }

            int n = random.nextInt(nombres.length);
            int a = random.nextInt(apellidos.length);

            empleadoVO.setNombreEmpleado(nombres[n]);
            empleadoVO.setApellidoEmpleado(apellidos[a]);
            sueldos[i] = empleadoVO.getSueldoEmpleado();
            arrayRut[i] = empleadoVO.getRutEmpleado();
            infoEmpleados.put(empleadoVO.getRutEmpleado(), empleadoVO);

        }

        bonificacion.setArraySueldo(sueldos);

    }
    
    public void agregarEmpleado(EmpleadoVO empleadoVO) {
        if (infoEmpleados.containsKey(empleadoVO.getRutEmpleado()) == false) {
            infoEmpleados.put(empleadoVO.getRutEmpleado(), empleadoVO);
            JOptionPane.showMessageDialog(null, "Paciente registrado correctamente",
                    "Resgistrar", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Este RUT ya se encuentra registrado, ingrese uno diferente",
                    "ERROR", 0);
        }
        
        int[] arraySueldos = new int[infoEmpleados.size()];
        for (int i = 0; i < infoEmpleados.size(); i++) {
            if (infoEmpleados.get(i) != null) {
                arraySueldos[i] = infoEmpleados.get(i).getSueldoEmpleado();
            }

        }
    }

    public void modificarEmpleado(int rut, EmpleadoDAO empleadoDAO) {

        if (infoEmpleados.containsKey(rut) == true) {
            ActualizarEmpleado ventana = new ActualizarEmpleado(rut, getInfoEmpleados(), empleadoDAO);
            ventana.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Este RUT no se encuentra registrado, intentelo de nuevo.",
                    "ERROR", 0);

        }

    }

    public void actualizarEmpleado(EmpleadoVO empleadoVO) {
        infoEmpleados.replace(empleadoVO.getRutEmpleado(), empleadoVO);
        JOptionPane.showMessageDialog(null, "Se actualizo correctamente.", "Actualizar Empleado", 1);

        int[] arraySueldos = new int[100];
        for (int i = 0; i < infoEmpleados.size(); i++) {
            if (infoEmpleados.get(i) != null) {
                arraySueldos[i] = infoEmpleados.get(i).getSueldoEmpleado();
            }

        }
        bonificacion.setArraySueldo(arraySueldos);

    }

    public void eliminarEmpleado(int rut) {

        if (infoEmpleados.containsKey(rut) == true) {
            infoEmpleados.remove(rut);
            JOptionPane.showMessageDialog(null, "Se elimino correctamente", "Eliminar Empleado.", 1);
        } else {
            JOptionPane.showMessageDialog(null, "Este RUT no se encuentra registrado, intentelo de nuevo.", "Eliminar Empleado", 0);
        }

    }

}
