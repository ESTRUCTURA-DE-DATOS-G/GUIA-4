package guia3_empresa;

public class EmpleadoVO {

    private String nombreEmpleado, apellidoEmpleado;
    private int rutEmpleado, sueldoEmpleado, sueldoMasAumento;

//Constructor de Empleado

    public EmpleadoVO(String nombreEmpleado, String apellidoEmpleado, int rutEmpleado, int sueldoEmpleado, int sueldoMasAumento) {
        this.nombreEmpleado = nombreEmpleado;
        this.apellidoEmpleado = apellidoEmpleado;
        this.rutEmpleado = rutEmpleado;
        this.sueldoEmpleado = sueldoEmpleado;
        this.sueldoMasAumento = sueldoMasAumento;
    }
    

//Constructor vacio de Empleado
    public EmpleadoVO() {
        this.nombreEmpleado = "";
        this.apellidoEmpleado = "";
        this.rutEmpleado = 0;
        this.sueldoEmpleado = 0;
        this.sueldoMasAumento=0;
    }

//Setter y getters de Empleado
    public int getSueldoMasAumento() {
        return sueldoMasAumento;
    }

    public void setSueldoMasAumento(int sueldoMasAumento) {
        this.sueldoMasAumento = sueldoMasAumento;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getApellidoEmpleado() {
        return apellidoEmpleado;
    }

    public void setApellidoEmpleado(String apellidoEmpleado) {
        this.apellidoEmpleado = apellidoEmpleado;
    }

    public int getRutEmpleado() {
        return rutEmpleado;
    }

    public void setRutEmpleado(int rutEmpleado) {
        this.rutEmpleado = rutEmpleado;
    }

    public int getSueldoEmpleado() {
        return sueldoEmpleado;
    }

    public void setSueldoEmpleado(int sueldoEmpleado) {
        this.sueldoEmpleado = sueldoEmpleado;
    }

}
