package guia3_empresa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Bonificacion {

    private int[] arraySueldo;
    private int[] sueldosMasBajos;
    private int totalBonificaciones;

    private HashMap<Integer, EmpleadoVO> empleadosBeneficiados;
    private int mayorBonificacion;
    private int menorBonificacion;
    private int[] salarioMasAumento;

    public Bonificacion(int[] arraySueldo, int[] sueldosMasBajos, HashMap<Integer, EmpleadoVO> empleadosBeneficiados, int mayorBonificacion, int menorBonificacion, int[] salarioMasAumento) {
        this.arraySueldo = arraySueldo;
        this.sueldosMasBajos = sueldosMasBajos;
        this.empleadosBeneficiados = empleadosBeneficiados;
        this.mayorBonificacion = mayorBonificacion;
        this.menorBonificacion = menorBonificacion;
        this.salarioMasAumento = salarioMasAumento;
    }

    public Bonificacion() {
        this.arraySueldo = new int[0];
        this.sueldosMasBajos = new int[0];
        this.empleadosBeneficiados = new HashMap<>();
        this.salarioMasAumento = new int[0];
        this.totalBonificaciones = 0;
    }

    public int getTotalBonificaciones() {
        return totalBonificaciones;
    }

    public void setTotalBonificaciones(int totalBonificaciones) {
        this.totalBonificaciones = totalBonificaciones;
    }

    public int[] getSalarioMasAumento() {
        return salarioMasAumento;
    }

    public void setSalarioMasAumento(int[] salarioMasAumento) {
        this.salarioMasAumento = salarioMasAumento;
    }

    public int getMayorBonificacion() {
        return mayorBonificacion;
    }

    public void setMayorBonificacion(int mayorBonificacion) {
        this.mayorBonificacion = mayorBonificacion;
    }

    public int getMenorBonificacion() {
        return menorBonificacion;
    }

    public void setMenorBonificacion(int menorBonificacion) {
        this.menorBonificacion = menorBonificacion;
    }

    public HashMap<Integer, EmpleadoVO> getEmpleadosBeneficiados() {
        return empleadosBeneficiados;
    }

    public void setEmpleadosBeneficiados(HashMap<Integer, EmpleadoVO> empleadosBeneficiados) {
        this.empleadosBeneficiados = empleadosBeneficiados;
    }

    public int[] getArraySueldo() {
        return arraySueldo;
    }

    public void setArraySueldo(int[] arraySueldo) {
        this.arraySueldo = arraySueldo;
    }

    public int[] getSueldosMasBajos() {
        return sueldosMasBajos;
    }

    public void setSueldosMasBajos(int[] sueldosMasBajos) {
        this.sueldosMasBajos = sueldosMasBajos;
    }

    public void SueldosMasBajos(EmpleadoDAO empleadoDAO) {
        empleadosBeneficiados = new HashMap<>();
        Arrays.sort(empleadoDAO.getArraySueldos());
        DatosRepetidos(empleadoDAO);

        int k = 0;

        for (int i = 0; i < empleadoDAO.getInfoEmpleados().size(); i++) {
            for (int j = 0; j < sueldosMasBajos.length; j++) {
                EmpleadoVO empleadoVO = empleadoDAO.getInfoEmpleados().get(empleadoDAO.getArrayRut()[i]);

                if (empleadoVO != null) {
                    if (empleadoVO.getSueldoEmpleado() == sueldosMasBajos[j]) {
                        empleadosBeneficiados.put(empleadoVO.getRutEmpleado(), empleadoVO);

                    }
                }
            }

        }

    }

    public void MayorBonificacion() {
        mayorBonificacion = sueldosMasBajos[0];
        for (int i = 1; i < sueldosMasBajos.length; i++) {
            if (sueldosMasBajos[i] > mayorBonificacion) {
                mayorBonificacion = (int) (sueldosMasBajos[i]);
            }
        }

    }

    public void MenorBonificacion() {
        menorBonificacion = sueldosMasBajos[0];
        for (int i = 1; i < sueldosMasBajos.length; i++) {
            if (sueldosMasBajos[i] < menorBonificacion) {
                menorBonificacion += (int) (sueldosMasBajos[i]);

            }
        }
    }

    public void totalBonificaciones() {

        totalBonificaciones = 0;

        int fila = 0;
        for (Map.Entry<Integer, EmpleadoVO> entry : empleadosBeneficiados.entrySet()) {
            EmpleadoVO e = entry.getValue();
            totalBonificaciones += e.getSueldoMasAumento();
            fila++;
        }

    }

    public void DatosRepetidos(EmpleadoDAO empleadoDAO) {
        int[] b = new int[empleadoDAO.getArraySueldos().length];

        int j = 0;
        int top = 0;
        boolean repetido;

        for (int i = 0; i < 30; i++) {
            repetido = false;
            j = 0;

            while (!repetido && (j < top)) {
                if (empleadoDAO.getArraySueldos()[i] == b[j]) {
                    repetido = true;
                }
                j++;
            }
            if (!repetido) {
                b[top] = empleadoDAO.getArraySueldos()[i];
                top++;
            }
        }
        sueldosMasBajos = new int[top];

        for (int i = 0; i < top; i++) {
            sueldosMasBajos[i] = b[i];
        }

    }

}
